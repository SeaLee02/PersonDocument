﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace SeaLee.WeiXin.Web
{
    /// <summary>
    /// 初始化微信参数,把此类在全球文件中注册一下就会生效
    /// </summary>
    public class WeixinConfig
    {
        public static string AppID {  get; private set; }
        public static string AppSecret {  get; private set; }

        public static string Token { get; private set; }
        public static void Regist()
        {
            AppID = ConfigurationManager.AppSettings["AppID"];
            AppSecret = ConfigurationManager.AppSettings["AppSecret"];
            Token = ConfigurationManager.AppSettings["Token"];
        }
    }
}
