﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace SeaLee.WeiXin.Web
{
    //Global.asax 全球文件
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);  //注册路由规则
            WeixinConfig.Regist();     //注册微信配置
        }
    }
}
