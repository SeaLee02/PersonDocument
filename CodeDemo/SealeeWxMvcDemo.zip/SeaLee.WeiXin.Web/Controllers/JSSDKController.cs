﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SeaLee.WeiXin.SDK;
using SeaLee.WeiXin.Web.Models;
using System.Net;
using System.Net.Http;

namespace SeaLee.WeiXin.Web.Controllers
{
    public class JSSDKController : Controller
    {
        // GET: JSSDK
        public ActionResult Index()
        {
            var access_token = BaseAPI.GetAccessToken(WeixinConfig.AppID, WeixinConfig.AppSecret);
            var jsTicket = JsSDKAPI.GetTickect(access_token);
            //随机数，时间戳    需要跟前台的wx.Config保持一致的
            var nonceStr = Util.CreateNonce_str();
            var timestamp = Util.CreateTimestamp();
            var signature = JsSDKAPI.GetSignature(nonceStr, jsTicket, timestamp, Request.Url.AbsoluteUri);//Request.Url.AbsoluteUri 获取请求的URL

            var jskModel = new JSSDKModel()     //创建一个JSSDKModel来保存信息
            {
                appId = WeixinConfig.AppID,
                nonceStr = nonceStr,
                timestamp = timestamp,
                jsapiTicket = jsTicket,
                signature = signature
            };
            return View(jskModel);  //返回强类型
        }


        public string EncodGPS(string latitude, string longitude)
        {
            dynamic oldGPS = GetLocation.TranCoord(latitude, longitude);
            string lat = oldGPS.result[0].y;
            string lon = oldGPS.result[0].x;
            string address = GetLocation.Address(lat, lon);
            return address;
        }

    }
}