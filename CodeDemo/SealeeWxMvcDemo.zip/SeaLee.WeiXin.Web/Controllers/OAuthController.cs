﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SeaLee.WeiXin.Web.Models;
using SeaLee.WeiXin.SDK;
using System.Web.Script.Serialization;

namespace SeaLee.WeiXin.Web.Controllers
{
    public class OAuthController : Controller
    {
        // GET: OAuth
        /// <summary>
        /// 由公号号进入这个方法
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            var appID = WeixinConfig.AppID;
            //state 保证是唯一值就可以了  
            var url = string.Format("https://open.weixin.qq.com/connect/oauth2/authorize?appid={0}&redirect_uri={1}&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect",
                appID, "http://www.sealee.xin/OAuth/Callback");
            return Redirect(url);
        }

        /// <summary>
        /// 授权之后回调页面
        /// </summary>
        /// <param name="code">每次带的code都不一样</param>
        /// <param name="state"></param>
        /// <returns></returns>
        public ActionResult Callback(string code, string state)
        {
            dynamic tokenDynamic = OAuth2API.GetAccessToken(code, WeixinConfig.AppID, WeixinConfig.AppSecret);
           // NetLog.WriteTextLog("Callback", tokenDynamic.access_token.ToString(), DateTime.Now);  注意传递的参数类型
            if (!string.IsNullOrEmpty(tokenDynamic.errmsg)) return Content("错误消息：" + tokenDynamic.errmsg);//new JavaScriptSerializer().Serialize(token) 把类序列化成JSON输出
           //如果需要可以在这里刷新access_token
            dynamic uinfo = OAuth2API.GetUserInfo(tokenDynamic.access_token.ToString(), tokenDynamic.openid.ToString());//注意传递的参数类型,需要转型就转
            if (!string.IsNullOrEmpty(uinfo.errmsg)) return Content("错误消息:" + uinfo.errmsg);
            var content = "<img src='" + uinfo.headimgurl + "' />" + "<br>" +
                   "国家：" + uinfo.country + "城市：" + uinfo.city + "<br>" +
                   "姓名：" + uinfo.nickname + "关注时间:" + uinfo.subscribe_time;
            return Content(content);
        }
    }
}