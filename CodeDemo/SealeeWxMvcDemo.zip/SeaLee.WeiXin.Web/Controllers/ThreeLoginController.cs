﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SeaLee.WeiXin.Web.Controllers
{
    public class ThreeLoginController : Controller
    {
        // GET: ThreeLogin
        public ActionResult Index()
        {
            string url = HttpUtility.UrlEncode("http://sealee.xin/ThreeLogin/RedirectDemo");
            string urlAPI = string.Format("https://open.weixin.qq.com/connect/qrconnect?appid={0}&redirect_uri={1}&response_type=code&scope=snsapi_login&state=1#wechat_redirect",
                WeixinConfig.AppID,url);
            ViewBag.URL = urlAPI;
            return View();
        }


        public ActionResult RedirectDemo(string code,string state)
        {
            ViewBag.CODE = code;
            return View();
        }
    }
}