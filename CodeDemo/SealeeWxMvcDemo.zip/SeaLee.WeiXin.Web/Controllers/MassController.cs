﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SeaLee.WeiXin.SDK;
using SeaLee.WeiXin.SDK.Entities;
using System.IO;

namespace SeaLee.WeiXin.Web.Controllers
{
    public class MassController : Controller
    {
        // GET: Mass
        public ActionResult Index()
        {
            string accessToken = BaseAPI.GetAccessToken(WeixinConfig.AppID, WeixinConfig.AppSecret);
            string diaID = "3nMCVVzZmevVVRLB2LZUCwxjuNus3k2YpnXR6Uqs52s";//永久图文消息的media_id
          
            #region 群发     
            dynamic previewObject = MassMessageAPI.Preview(accessToken, "oJU5QvxZb8Jy90FTl9xhatayygfw", diaID, WxArtcleType.News);
            string dd = previewObject.errmsg;
            string pcode = previewObject.errcode;
            NetLog.WriteTextLog("Mass1", dd + "," + pcode, DateTime.Now);
            #endregion
            return Content(dd);

        }

        [HttpGet]
        [ActionName("UpFiles")]
        public ActionResult Get()
        {
            return View();
        }

        [HttpPost]
        [ActionName("UpFiles")]
        public ActionResult Post()
        {
            var file = Request.Files[0]; //获取到上传的文件
            string accessToken = BaseAPI.GetAccessToken(WeixinConfig.AppID, WeixinConfig.AppSecret);
            //新增临时素材
            //var mediaID = MaterialAPI.UploadTempMedia(accessToken, "thumb", file.FileName, file.InputStream); //传值进行
           
            //永久素材
            var mediaID = MaterialAPI.UploadMedia(accessToken, "thumb", file.FileName, file.InputStream);

            var artcle = new WxArtcle()
            {
                thumb_media_id = mediaID,
                author = "sealee",
                content = "这是我的测试类容，发的是永久图文素材",
                digest = "永久图文消息",
                title = "图文消息",
                content_source_url = "www.baidu.com",
                show_cover_pic = "0"
            };
            //永久素材
            dynamic uploadObjct = MaterialAPI.UploadNews(accessToken, new List<WxArtcle> { artcle });
            //上传图文消息
            //dynamic uploadObjct = MassMessageAPI.Uploadnews(accessToken, new List<WxArtcle> { artcle });
            string content = uploadObjct.errmsg;
            string code = uploadObjct.errcode;
            string diaID = uploadObjct.media_id;  //永久图文消息的media_id
            return Content(content + "," + diaID);  //成功后需要得到 diaID
        }

    }
}