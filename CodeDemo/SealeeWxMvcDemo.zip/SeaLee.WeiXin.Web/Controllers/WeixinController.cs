﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SeaLee.WeiXin.SDK;
using System.Text;
using System.IO;
using System.Web.Script.Serialization;
using SeaLee.WeiXin.SDK.Entities;

namespace SeaLee.WeiXin.Web.Controllers
{
    public class WeixinController : Controller
    {
        /// <summary>
        /// 验证微信服务器
        /// </summary>
        [HttpGet]
        [ActionName("Index")]

        public ActionResult Get(string signature, string timestamp, string nonce, string echostr)
        {
            //验证签名和创建菜单都会记住状态，用一次关闭就可以了
            #region  验证签名
            //var token = WeixinConfig.Token;//微信公众平台后台设置的Token
            //if (string.IsNullOrEmpty(token)) return Content("请先设置Token！");
            //if (!BaseAPI.CheckSignature(signature, timestamp, nonce, token))
            //{
            //    return Content("参数错误");
            //}
            //return Content(echostr); //返回随机字符串则表示验证通过
            #endregion
            #region 创建菜单   
            var token = BaseAPI.GetAccessToken(WeixinConfig.AppID, WeixinConfig.AppSecret);
            return Content(CustomMenuAPI.Create(token, GetWeixinMenu()) + "");
            #endregion

            //return Content("");

        }
        ///Weixin/Index?signature=66d9e84e4f6cc36760aa3226aa14456605ef53ff&timestamp=1519896287&nonce=437598829&openid=oJU5QvxZb8Jy90FTl9xhatayygfw
        [HttpPost]
        [ActionName("Index")]
        public ActionResult Post(string signature, string timestamp, string nonce, string echostr)
        {
            WxMessage message = null;
            using (var streamReader = new StreamReader(Request.InputStream))
            {
                var msg = streamReader.ReadToEnd();//公众号接收的xml消息
                message = AcceptMessageAPI.Pare(msg);//xml转化为动态类
            }
            var response = new WxExecutor().Execute(message); //根据接收的xml来决定返回什么
            return new ContentResult
            {
                Content = response,
                ContentType = "text/xml",
                ContentEncoding = System.Text.UTF8Encoding.UTF8
            };
        }

        /// <summary>
        /// 有关菜单的模板
        /// https://mp.weixin.qq.com/wiki?t=resource/res_main&id=mp1421141013  
        /// 注意你的菜单json字符串 要保证正确
        /// </summary>
        /// <returns></returns>
        public string GetWeixinMenu()
        {
            StringBuilder menStr = new StringBuilder();
            menStr.AppendLine("{");
            menStr.AppendLine("\"button\":[");

            //第一个主菜单 没有子菜单
            menStr.AppendLine("{");
            menStr.AppendLine("\"type\":\"click\",");
            menStr.AppendLine("\"name\":\"点击事件\",");
            menStr.AppendLine("\"key\":\"test01\"");  //这个key对应的值是用来做这个事件处理的,这里就不写了，后面会介绍
            menStr.AppendLine("},");

            //第二个主菜单,有子菜单的
            menStr.AppendLine("{");
            menStr.AppendLine("\"name\":\"测试功能\",");
            menStr.AppendLine("\"sub_button\":[");
            //子菜单
            menStr.AppendLine("{");
            menStr.AppendLine("\"type\":\"view\",");
            menStr.AppendLine("\"name\":\"JSSDK接口\",");
            menStr.AppendLine("\"url\":\"http://www.sealee.xin/JSSDK/Index\"");
            menStr.AppendLine(" },");
            menStr.AppendLine("{");
            menStr.AppendLine("\"type\":\"view\",");
            menStr.AppendLine("\"name\":\"网页授权\",");
            menStr.AppendLine("\"url\":\"http://www.sealee.xin/OAuth/Index\"");
            menStr.AppendLine(" }");

            //menStr.AppendLine("{");
            //menStr.AppendLine("\"type\":\"view\",");
            //menStr.AppendLine("\"name\":\"群发接口\",");
            //menStr.AppendLine("\"url\":\"http://www.sealee.xin/Mass/UpFiles\"");
            //menStr.AppendLine("}");


            menStr.AppendLine("]}");

            menStr.AppendLine("]}");
            return menStr.ToString();

        }



        public ActionResult Test()
        {
            //string response = @"<xml><ToUserName><![CDATA[gh_94c36e77a998]]></ToUserName> 
            //<FromUserName><![CDATA[oJU5QvxZb8Jy90FTl9xhatayygfw]]></FromUserName>
            //<CreateTime> 1520401756</CreateTime>
            //<MsgType><![CDATA[text]]>
            //</MsgType><Content><![CDATA[欢迎使用: 您输入了：你好]]></Content></xml>";
            //return new ContentResult
            //{
            //    Content = response,
            //    ContentType = "text/xml",
            //    ContentEncoding = System.Text.UTF8Encoding.UTF8
            //};
            //var artcle = new WxArtcle()
            //{
            //    thumb_media_id = "1231123",
            //    author = "sealee",
            //    content = "这是我的测试类容，好的好的后打哈按时大大啊",
            //    digest = "测试图文消息描述",
            //    title = "图文消息",
            //    content_source_url = "www.baidu.com",
            //    show_cover_pic = "1"
            //};

            //StringBuilder builder = new StringBuilder();
            //builder.Append("{")
            //    .Append("\"articles\":")
            //    .Append("[")
            //    .Append(JsonHelp.Serialize(artcle))
            //    .Append("]")
            //    .Append("}");
  
            return Content(WxArtcleType.News.ToString());


            //            { "item":[    5条
            //            {"media_id":"3nMCVVzZmevVVRLB2LZUCyv6rRsGZbyOUES32kKmFk4",
            //            "name":"gotop.jpg","update_time":1520921356,
            //            "url":"http:\/\/mmbiz.qpic.cn\/mmbiz_png\/7gs7HAzBPzjiaZOEia91YSH5cc14oWuNLIaeaqRicXiaVhMKl0CJqyVmJmGQeicfRYm1CD6eesOfk9OMbtv1ibiaVgiaUw\/0?wx_fmt=png"},
            //        {"media_id":"3nMCVVzZmevVVRLB2LZUCxpMNq9PGbu7tLlrQg1jwGo","name":"gotop.jpg","update_time":1520920958,
            //        "url":"http:\/\/mmbiz.qpic.cn\/mmbiz_png\/7gs7HAzBPzjiaZOEia91YSH5cc14oWuNLIaeaqRicXiaVhMKl0CJqyVmJmGQeicfRYm1CD6eesOfk9OMbtv1ibiaVgiaUw\/0?wx_fmt=png"},
            //{"media_id":"3nMCVVzZmevVVRLB2LZUC6rTAyQlCnvL6YRZuLHuoYY","name":"api_mpnews_cover.jpg","update_time":1520908124,"url":""},
            //{"media_id":"3nMCVVzZmevVVRLB2LZUCwTNgb0rcnPO9Lx2rnklHwI","name":"api_mpnews_cover.jpg","update_time":1520907896,"url":""},
            //{"media_id":"3nMCVVzZmevVVRLB2LZUC5o2beLW-v1gYXPmjQvjhoI","name":"api_mpnews_cover.jpg","update_time":1520907579,"url":""}],
            //"total_count":2,"item_count":5}


//            { "item":[
//            {"media_id":"3nMCVVzZmevVVRLB2LZUCyv6rRsGZbyOUES32kKmFk4","name":"gotop.jpg","update_time":1520921356,
//            "url":"http:\/\/mmbiz.qpic.cn\/mmbiz_png\/7gs7HAzBPzjiaZOEia91YSH5cc14oWuNLIaeaqRicXiaVhMKl0CJqyVmJmGQeicfRYm1CD6eesOfk9OMbtv1ibiaVgiaUw\/0?wx_fmt=png"},
//        {"media_id":"3nMCVVzZmevVVRLB2LZUCxpMNq9PGbu7tLlrQg1jwGo","name":"gotop.jpg","update_time":1520920958,
//        "url":"http:\/\/mmbiz.qpic.cn\/mmbiz_png\/7gs7HAzBPzjiaZOEia91YSH5cc14oWuNLIaeaqRicXiaVhMKl0CJqyVmJmGQeicfRYm1CD6eesOfk9OMbtv1ibiaVgiaUw\/0?wx_fmt=png"}],
//"total_count":2,"item_count":2}





        }

    }
}