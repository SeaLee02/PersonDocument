﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeaLee.WeiXin.Web.Models
{
    public class JSSDKModel
    {
        /// <summary>
        /// APPID
        /// </summary>
        public string appId { set; get; }
        /// <summary>
        /// 时间戳
        /// </summary>
        public long timestamp { set; get; }
        /// <summary>
        /// 时间字符串
        /// </summary>
        public string nonceStr { set; get; }
        /// <summary>
        /// jsTicket
        /// </summary>
        public string jsapiTicket { set; get; }
        /// <summary>
        /// 签名
        /// </summary>
        public string signature { set; get; }

    }
}
