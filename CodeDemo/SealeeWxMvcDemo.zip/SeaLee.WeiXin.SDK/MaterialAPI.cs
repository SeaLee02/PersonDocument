﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using SeaLee.WeiXin.SDK.Entities;

namespace SeaLee.WeiXin.SDK
{
    /// <summary>
    /// 对应微信API的 "素材管理"
    /// </summary>
    public class MaterialAPI
    {

        /// <summary>
        /// 新增临时素材/上传多媒体文件
        /// http://mp.weixin.qq.com/wiki/5/963fc70b80dc75483a271298a76a8d59.html
        /// 1.上传的媒体文件限制：
        ///图片（image) : 1MB，支持JPG格式
        ///语音（voice）：1MB，播放长度不超过60s，支持MP4格式
        ///视频（video）：10MB，支持MP4格式
        ///缩略图（thumb)：64KB，支持JPG格式
        ///2.媒体文件在后台保存时间为3天，即3天后media_id失效
        /// </summary>
        /// <param name="access_token"></param>
        /// <param name="type">媒体文件类型，分别有图片（image）、语音（voice）、视频（video）和缩略图（thumb）</param>
        /// <param name="fileName">文件名</param>
        /// <param name="inputStream">文件输入流</param>
        /// <returns>thumb_media_id</returns>
        public static string UploadTempMedia(string access_token, string type, string fileName, Stream inputStream)
        {
            var url = string.Format("https://api.weixin.qq.com/cgi-bin/media/upload?access_token={0}&type={1}", access_token, type.ToString());
            var result = JsonHelp.ToDynamic(Util.HttpRequestPost(url, "media", fileName, inputStream)); 
            inputStream.Close();
            inputStream.Dispose();
            return result.thumb_media_id; //成功的时候有值
        }


        /// <summary>
        /// 获取临时素材/下载多媒体文件
        /// 公众号可以使用本接口获取临时素材（即下载临时的多媒体文件）。请注意，视频文件不支持https下载，调用该接口需http协议。
        /// 本接口即为原“下载多媒体文件”接口。
        /// </summary>
        /// <param name="savePath">列如：E:xxx/Images/123.jpg 需要确定到名称</param>
        /// <param name="access_token"></param>
        /// <param name="media_id">上传的media_id</param>
        public static void DownloadTempMedia(string savePath, string access_token, string media_id)
        {       
            var url = string.Format("https://api.weixin.qq.com/cgi-bin/media/get?access_token={0}&media_id={1}", access_token, media_id);
            FileStream fs = new FileStream(savePath, FileMode.Create);
            Util.Download(url, fs);
            fs.Close();
            fs.Dispose();
        }




         /// <summary>
         /// 新增永久素材
         /// </summary>
         /// <param name="access_token"></param>
         /// <param name="type">类型</param>
         /// <param name="fileName">文件名</param>
         /// <param name="inputStream">文件流</param>
         /// <returns></returns>
        public static string UploadMedia(string access_token, string type, string fileName, Stream inputStream)
        {
            var url = string.Format("https://api.weixin.qq.com/cgi-bin/material/add_material?access_token={0}&type={1}", access_token, type.ToString());
            var result = JsonHelp.ToDynamic(Util.HttpRequestPost(url, "media", fileName, inputStream));
            inputStream.Close();
            inputStream.Dispose();
            return result.media_id;
        }

        /// <summary>
        /// 上传永久图文素材
        /// </summary>
        /// <param name="access_token"></param>
        /// <param name="artcles">文章</param>
        /// <returns></returns>
        public static dynamic UploadNews(string access_token, List<WxArtcle> artcles)
        {
            var url = string.Format("https://api.weixin.qq.com/cgi-bin/material/add_news?access_token={0}", access_token);
            var client = new HttpClient();
            StringBuilder builder = new StringBuilder();
            builder.Append("{")
                    .Append("\"articles\":")
                    .Append(JsonHelp.Serialize(artcles))
                    .Append("}");
            var result = client.PostAsync(url, new StringContent(builder.ToString())).Result;
            return JsonHelp.ToDynamic(result.Content.ReadAsStringAsync().Result);
        }



        /// <summary>
        /// 获取素材总数
        /// </summary>
        /// <param name="access_token"></param>
        /// <returns></returns>
        public static string GetCount(string access_token)
        {
            var url = string.Format("https://api.weixin.qq.com/cgi-bin/material/get_materialcount?access_token={0}", access_token);
            var client = new HttpClient();
            var result = client.GetAsync(url).Result;
            return result.Content.ReadAsStringAsync().Result;
        }


        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="access_token"></param>
        /// <param name="media_id">素材的永久media_id</param>
        /// <returns></returns>
        public static bool Del(string access_token, string media_id)
        {
            var url = string.Format("https://api.weixin.qq.com/cgi-bin/material/del_material?access_token={0}", access_token);
            var clinet = new HttpClient();
            var result = clinet.PostAsync(url, new StringContent("{\"media_id\":\"" + media_id + "\"}")).Result;
            var objectData = JsonHelp.ToDynamic(result.Content.ReadAsStringAsync().Result);
            var code = objectData.errcode;
            return code == 0 ? true : false;
        }

        /// <summary>
        /// 获取素材列表  只能获取永久素材
        /// </summary>
        /// <param name="access_token"></param>
        /// <param name="type">类型</param>
        /// <param name="offset">开始的偏移量</param>
        /// <param name="count">素材的数量</param>
        /// <returns></returns>
        public static dynamic GetInfo(string access_token,WxArtcleType type, int offset, int count)
        {
            var url = string.Format("https://api.weixin.qq.com/cgi-bin/material/batchget_material?access_token={0}", access_token);
            var client = new HttpClient();
            var builder = new StringBuilder();
            builder.Append("{");
            builder.AppendFormat("\"type\":\"{0}\",", type.ToString().ToLower())
                   .AppendFormat("\"offset\":\"{0}\",", offset)
                   .AppendFormat("\"count\":\"{0}\"", count)
                   .Append("}");
            var result = client.PostAsync(url, new StringContent(builder.ToString())).Result;
            string aa = result.Content.ReadAsStringAsync().Result;
            NetLog.WriteTextLog("Info",aa,DateTime.Now);
            return JsonHelp.ToDynamic(aa);
        }
    }
}
