﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

namespace SeaLee.WeiXin.SDK
{

    /// <summary>
    /// https://mp.weixin.qq.com/wiki?t=resource/res_main&id=mp1421141115
    ///   微信JS-SDK说明文档
    /// </summary>
    public class JsSDKAPI
    {
        /// <summary>
        /// 获取jsApi   该接口次数有限,需要缓存
        /// </summary>
        /// <param name="access_token">BaseAPI获取的access_token</param>
        /// <returns>
        /// 成功时返回json数据
        // {
        //"errcode":0,
        //"errmsg":"ok",
        //"ticket":"bxLdikRXVbTPdHSM05e5u5sUoXNKd8-41ZO3MhKoyN5OfkWITDGgnr2fwJ0m9E8NYzWKVZvdVtaUgWvsdshFKA",
        //"expires_in":7200
        //}
        /// </returns>
        public static dynamic GetTickect(string access_token)
        {
            var url = string.Format("https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token={0}&type=jsapi",
            access_token);
            var client = new HttpClient();
            var result = client.GetAsync(url).Result;
            if (!result.IsSuccessStatusCode) return string.Empty;
            if (CacheHelper.Get("jsTickect") == null)
            {
                dynamic jsTickect = JsonHelp.ToDynamic(result.Content.ReadAsStringAsync().Result);
                CacheHelper.Insert("jsTickect", jsTickect.ticket, 60);//这个有次数限制，需要我们缓存  这里设置为1个小时
            }
            return CacheHelper.Get("jsTickect").ToString();
        }


        /// <summary>
        /// 签名算法
        /// </summary>
        /// <param name="noncestr">随机字符串(必须与wx.config中的nonceStr相同)</param>
        /// <param name="jsapi_ticket">jsapi_ticket</param>
        /// <param name="timestamp">时间戳(必须与wx.config中的timestamp相同)</param>
        /// <param name="url">当前网页的URL，不包含#及其后面部分(必须是调用JS接口页面的完整URL)</param>
        /// <returns></returns>
        public static dynamic GetSignature(string noncestr, string jsapi_ticket, long timestamp, string url)
        {
            var strSin = new StringBuilder();
            strSin.Append("jsapi_ticket=").Append(jsapi_ticket).Append("&");
            strSin.Append("noncestr=").Append(noncestr).Append("&");
            strSin.Append("timestamp=").Append(timestamp).Append("&");
            strSin.Append("url=").Append(url.IndexOf("#")>0? url.Substring(0, url.IndexOf("#")):url);
            var string1 = strSin.ToString();
            return Util.Sha1(string1);
        }

    }
}
