﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;


namespace SeaLee.WeiXin.SDK
{
    /// <summary>
    /// 此类是用来配置服务器的
    /// </summary>
    public class BaseAPI
    {
     
        /// <summary>
        /// 验证签名  是否来源于微信
        /// </summary>
        /// <param name="signature">需要比对的加密签名</param>
        /// <param name="timestamp">时间戳</param>
        /// <param name="nonce">随机数</param>
        /// <param name="token">token值</param>
        /// <returns>真则验证成功，假则验证失败</returns>
        public static bool CheckSignature(string signature, string timestamp, string nonce, string token)
        {
            var arr = new[] { token, timestamp, nonce }.OrderBy(x => x).ToArray();
            var arrString = string.Join("", arr);
            //进行编码
            var sha1 = System.Security.Cryptography.SHA1.Create();
            var sha1Arr = sha1.ComputeHash(Encoding.UTF8.GetBytes(arrString));
            StringBuilder enText = new StringBuilder();
            foreach (var b in sha1Arr)
            {
                enText.AppendFormat("{0:x2}", b);
            }
            return signature==enText.ToString();
        }

        /// <summary>
        ///获取AccessToken 
        /// </summary>
        /// <param name="appid">Appid</param>
        /// <param name="secrect">Secrect</param>
        /// <returns>返回json数据</returns>
        ///
        public static dynamic GetAccessToken(string appid, string secrect)
        {
            var url = string.Format("https://api.weixin.qq.com/cgi-bin/token?grant_type={0}&appid={1}&secret={2}", "client_credential", appid, secrect);
            var client = new HttpClient();
            var result = client.GetAsync(url).Result;
            if (!result.IsSuccessStatusCode) return string.Empty;
            if (CacheHelper.Get("token") == null)
            {
                dynamic token = JsonHelp.ToDynamic(result.Content.ReadAsStringAsync().Result);
                CacheHelper.Insert("token", token.access_token, 60);//有两个小时时间,这里故意设置为一个小时
            }
            return CacheHelper.Get("token").ToString();
        }

    }
}
