﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Dynamic;
using System.Reflection;

namespace SeaLee.WeiXin.SDK
{
    public class DynamicXml : DynamicObject  //不能直接实例化,我们只能继承它了
    {
        //可以根据具体需求来进行逻辑实现
        public XElement xNode;

        public DynamicXml(string text)
        {
            var doc = XDocument.Parse(text);
            this.xNode = new XElement(doc.Root);
        }
        public DynamicXml(XElement node)
        {
            this.xNode = node;
        }

        public DynamicXml()
        {

        }      

        /// <summary>
        /// 设置值  实例化该类的时候就会进入改方法
        /// </summary>
        /// <param name="binder">动态设置成员操作</param>
        /// <param name="value">值</param>
        /// <returns></returns>
        public override bool TrySetMember(SetMemberBinder binder, object value)
        {
            XElement setNode = xNode.Element(binder.Name);
            if (setNode != null)//如果存在改节点
            {
                setNode.SetValue(value);  //就直接赋值
            }
            else
            {
                if (value.GetType() == typeof(DynamicXml)) //如果值为动态就调用自己,知道值为确定类型
                {
                    this.xNode.Add(new XElement(binder.Name));
                }
                else
                {
                    this.xNode.Add(new XElement(binder.Name, value)); //添加节点
                }
            }
            return true;
        }


        //取值 实例化该类的时候就会进入改方法
        public override bool TryGetMember(GetMemberBinder binder, out object result)
        {
            XElement getNode = xNode.Element(binder.Name);
            if (getNode != null)
            {
                result = new DynamicXml(getNode);
            }
            else
            {
                result = new DynamicXml(binder.Name);    //result = null;  这是案例的返回值，如果这样我们做测试的时候Address就会为空,这里需要改一下
            }
            return true;
        }



        public override bool TryConvert(ConvertBinder binder, out object result)
        {
            if (binder.Type == typeof(string))
            {
                result = this.xNode.Value;
                return true;
            }
            else
            {
                result = null;
                return false;
            }
        }



        public override bool TryInvokeMember(
InvokeMemberBinder binder, object[] args, out object result)
        {
            Type xmlType = typeof(XElement);
            try
            {
                result = xmlType.InvokeMember(
                          binder.Name,
                          BindingFlags.InvokeMethod |
                          BindingFlags.Public |
                          BindingFlags.Instance,
                          null, this.xNode, args);
                return true;
            }
            catch
            {
                result = null;
                return false;
            }
        }
    }
}