﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
using System.Net;

namespace SeaLee.WeiXin.SDK
{
    public class Util
    {
        /// <summary>
        /// 根据文档给出的Sha1
        /// </summary>
        /// <param name="shaStr">需要计算的字符串</param>
        /// <param name="encode">编码类型</param>
        /// <returns></returns>
        public static string Sha1(string shaStr, string encode = "UTF-8")
        {
            var sha1 = new SHA1Managed(); //SHA1   是个抽象类不能直接实例,只能用承继它的子类
            byte[] sha1bytes = Encoding.GetEncoding(encode).GetBytes(shaStr); //把string转成byte[]
            byte[] resultHash = sha1.ComputeHash(sha1bytes); //需要传入byte[]  
            string sha1String = BitConverter.ToString(resultHash).ToLower();  //再把byte[]转成string
            sha1String = sha1String.Replace("-", "");//去掉 - 
            return sha1String;
        }

        /// <summary>
        /// 获取时间戳
        /// </summary>
        /// <returns></returns>
        public static long CreateTimestamp()
        {
            //DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1, 0, 0, 0, 0));
            //long t = (DateTime.Now.Ticks - startTime.Ticks); 
            //return t.ToString().PadRight(18, '0');
            //两种都可以
            return (DateTime.Now.ToUniversalTime().Ticks - 621355968000000000) / 10000000;

        }


        private static string[] strs = new string[]
                             {
                                  "a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z",
                                  "A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"
                             };
        /// <summary>
        /// 创建随机字符串
        /// </summary>
        /// <returns></returns>
        public static string CreateNonce_str()
        {
            Random r = new Random();
            var sb = new StringBuilder();
            var length = strs.Length;
            for (int i = 0; i < 15; i++)
            {
                sb.Append(strs[r.Next(length - 1)]);
            }
            return sb.ToString();
        }



        /// <summary>
        /// From表单上传一个多媒体文件
        /// </summary>
        /// <param name="url">地址</param>
        /// <param name="typeName">类型名称</param>
        /// <param name="fileName">文件名称</param>
        /// <param name="fs">输入流</param>
        /// <param name="encoding">编码</param>
        /// <returns></returns>
        public static string HttpRequestPost(string url, string typeName, string fileName, Stream fs, string encoding = "UTF-8")
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url); //创建url
            request.Method = "POST";
            request.Timeout = 10000;
            var postStream = new MemoryStream();//创建内存流来进行数据处理
            #region 处理Form表单文件上传
            //通过表单上传文件
            string boundary = "----" + DateTime.Now.Ticks.ToString("x");
            //头部
            string formdataTemplate = "\r\n--" + boundary + "\r\nContent-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\nContent-Type: application/octet-stream\r\n\r\n";
            try
            {
                string formdata = string.Format(formdataTemplate, typeName, fileName);
                var formdataBytes = Encoding.ASCII.GetBytes(postStream.Length == 0 ? formdata.Substring(2, formdata.Length - 2) : formdata);//第一行不需要换行
                postStream.Write(formdataBytes, 0, formdataBytes.Length); //填充内存流
                //写入文件
                byte[] buffer = new byte[1024];
                int bytesRead = 0;
                while ((bytesRead = fs.Read(buffer, 0, buffer.Length)) != 0) //填充输入流
                {
                    postStream.Write(buffer, 0, bytesRead);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //结尾
            var footer = Encoding.ASCII.GetBytes("\r\n--" + boundary + "--\r\n");
            postStream.Write(footer, 0, footer.Length);
            request.ContentType = string.Format("multipart/form-data; boundary={0}", boundary);
            #endregion
            request.ContentLength = postStream != null ? postStream.Length : 0; //设置类容长度
             //request.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
            //request.KeepAlive = true;
            //request.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36";
            if (postStream != null)
            {
                postStream.Position = 0;
                //直接写入流
                Stream requestStream = request.GetRequestStream();
                byte[] buffer = new byte[1024];
                int bytesRead = 0;
                while ((bytesRead = postStream.Read(buffer, 0, buffer.Length)) != 0)
                {
                    requestStream.Write(buffer, 0, bytesRead);
                }
                postStream.Close();//关闭文件访问
            }
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            using (Stream responseStream = response.GetResponseStream())
            {
                using (StreamReader myStreamReader = new StreamReader(responseStream, Encoding.GetEncoding(encoding)))
                {
                    string retString = myStreamReader.ReadToEnd();
                    return retString; //返回结果
                }
            }
        }



        /// <summary>
        /// 下载
        /// </summary>
        /// <param name="url"></param>
        /// <param name="stream"></param>
        public static void Download(string url, Stream stream)
        {
            WebClient wc = new WebClient();
            var data = wc.DownloadData(url);
            foreach (var b in data)
            {
                stream.WriteByte(b);
            }
        }
    }
}
