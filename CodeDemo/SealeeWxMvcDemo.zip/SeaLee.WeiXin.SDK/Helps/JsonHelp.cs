﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Newtonsoft.Json;

namespace SeaLee.WeiXin.SDK
{
   public class JsonHelp
    {
        private static JavaScriptSerializer js = new JavaScriptSerializer();
        /// <summary>
        /// 返回键值对类型   
        /// </summary>
        /// <param name="json"></param>
        /// <returns></returns>
        public static Dictionary<string, object> ToDictionary(string json)
        {          
           return  (Dictionary<string, object>)js.DeserializeObject(json);
        }

        /// <summary>
        /// 返回强类型
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="json"></param>
        /// <returns></returns>
        public static T ToModel<T>(string json)
        {
            return (T)js.Deserialize<T>(json);
        }

        /// <summary>
        /// 将对象转化为JSON字符串
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string Serialize(object obj)
        {
          return  js.Serialize(obj);

        }

        /// <summary>
        /// 返回动态类型  这个比较方便   
        /// 需要引用我们的：Newtonsoft.Json.dll
        /// 使用它的   JsonConvert来序列化成对象 把dynamic传进去就可以了
        /// </summary>
        /// <param name="json"></param>
        /// <returns></returns>
        public static dynamic ToDynamic(string json)
        {
            return JsonConvert.DeserializeObject<dynamic>(json);//把传入的josn字符串返回成动态类型
        }


    }
}
