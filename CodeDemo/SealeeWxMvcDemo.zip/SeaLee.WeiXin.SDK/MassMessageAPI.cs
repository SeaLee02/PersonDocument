﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SeaLee.WeiXin.SDK.Entities;
using System.Net.Http;
using System.IO;

namespace SeaLee.WeiXin.SDK
{
    /// <summary>
    /// 群发接口和原创校验
    /// https://mp.weixin.qq.com/wiki?t=resource/res_main&id=mp1481187827_i0l21
    /// </summary>
    public class MassMessageAPI
    {


        /// <summary>
        ///上传图文消息内的图片获取URL,可以用在后续的群发文图中的类容
        ///【订阅号与服务号认证后均可用】
        /// </summary>
        /// <param name="access_token"></param>
        /// <param name="fileName"></param>
        /// <param name="inputStream"></param>
        /// <returns>图文中图片的URL</returns>
        public static string UploadImgForNews(string access_token, string fileName, Stream inputStream)
        {
            var url = string.Format("https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token={0}", access_token);
            var result = JsonHelp.ToDynamic(Util.HttpRequestPost(url, "image", fileName, inputStream));
            inputStream.Close();
            inputStream.Dispose();
            return result.url; //使用的时候还是需要在我们的Mass/UpFiles  页面上传进行来获取URL
        }



        /// <summary>
        /// 上传图文消息素材【订阅号与服务号认证后均可用】
        /// thumb_media_id:图文消息缩略图的media_id:
        /// 可以是上传的临时素材media_id,也可以是永久素材的media_id
        /// </summary>
        /// <param name="access_token"></param>
        /// <param name="artcles">图文消息，一个图文消息支持1到10条图文</param>
        /// <returns>success: { "type":"news","media_id":"CsEf3ldqkAYJAU6EJeIkStVDSvffUJ54vqbThMgplD-VJXXof6ctX5fI6-aYyUiQ", "created_at":1391857799}</returns>
        public static dynamic Uploadnews(string access_token, List<WxArtcle> artcles)
        {
            var url = string.Format("https://api.weixin.qq.com/cgi-bin/media/uploadnews?access_token={0}", access_token);
            var client = new HttpClient();

            StringBuilder builder = new StringBuilder();
            builder.Append("{")
                .Append("\"articles\":")
                .Append(JsonHelp.Serialize(artcles))
                .Append("}");
            NetLog.WriteTextLog("UpNews",builder.ToString(),DateTime.Now);
            var result = client.PostAsync(url, new StringContent(builder.ToString())).Result;
            return JsonHelp.ToDynamic(result.Content.ReadAsStringAsync().Result);
        }


        /// <summary>
        /// 回复复视频消息里面的media_id不是基础支持接口返回的media_id，这里需要给基础支持的media添加title和description
        /// </summary>
        /// <param name="access_token"></param>
        /// <param name="media_id"></param>
        /// <param name="title"></param>
        /// <param name="description"></param>
        /// <returns>success:{"type":"video","media_id":"IhdaAQXuvJtGzwwc0abfXnzeezfO0NgPK6AQYShD8RQYMTtfzbLdBIQkQziv2XJc","created_at":1398848981}
        /// </returns>
        public static dynamic UploadVideo(string access_token, string media_id, string title, string description)
        {
            var url = string.Format("https://file.api.weixin.qq.com/cgi-bin/media/uploadvideo?access_token={0}", access_token);
            var client = new HttpClient();
            var builder = new StringBuilder();
            builder
                .Append("{")
                .AppendFormat("\"media_id\":\"{0}\"",media_id).Append(",")
                .AppendFormat("\"title\":\"{0}\"",title)
                .AppendFormat("\"description\":\"{0}\"",description)
                .Append("}");
            var result = client.PostAsync(url, new StringContent(builder.ToString())).Result;
            return JsonHelp.ToDynamic(result.Content.ReadAsStringAsync().Result);
        }



        /// <summary>
        /// 根据OpenID列表群发【订阅号不可用，服务号认证后可用】
        /// </summary>
        /// <param name="access_token"></param>
        /// <param name="content">图文消息,语音,图片,视频:media_id; 文本:文本消息</param>
        /// <param name="type"></param>
        /// <param name="touser"></param>
        /// <returns>success:{"errcode":0,"errmsg":"send job submission success","msg_id":34182}</returns>
        public static dynamic ReplayOpenids(string access_token, string content, WxArtcleType type, IEnumerable<string> touser, string videoTitle, string videoDesc)
        {
            var url = string.Format("https://api.weixin.qq.com/cgi-bin/message/mass/send?access_token={0}", access_token);
            var client = new HttpClient();
            var builder = new StringBuilder();
            builder.Append("{")
            .Append("\"touser\":")
            .Append("[");
            string aa = "";
            foreach (var t in touser)
            {
                aa += string.Format("\"{0}\",", t);
            }
            aa=aa.TrimEnd(',');
            builder.Append(aa);
            builder.Append("],");
            switch (type)
            {
                case WxArtcleType.News:
                    builder.Append("\"mpnews\":")
                        .Append("{")
                        .AppendFormat("\"media_id\":\"{0}\"", content)
                        .Append("},")
                        .Append("\"msgtype\":\"mpnews\",")
                        .Append("\"send_ignore_reprint\":\"0\"");                         
                    break;
                case WxArtcleType.Text:
                    builder.Append("\"text\":")
                       .Append("{")
                       .AppendFormat("\"content\":\"{0}\"", content)
                       .Append("},")
                       .Append("\"msgtype\":\"text\"");
                    break;
                case WxArtcleType.Voice:
                    builder.Append("\"voice\":")
                           .Append("{")
                           .AppendFormat("\"media_id\":\"{0}\"", content)
                           .Append("},")
                           .Append("\"msgtype\":\"voice\"");
                    break;
                case WxArtcleType.Image:
                    builder.Append("\"image\":")
                          .Append("{")
                          .AppendFormat("\"media_id\":\"{0}\"", content)
                          .Append("},")
                          .Append("\"msgtype\":\"image\"");
                    break;
                case WxArtcleType.Video:
                    builder.Append("\"video\":")
                          .Append("{")
                          .AppendFormat("\"media_id\":\"{0}\",", content)
                          .AppendFormat("\"title\":\"{0}\",", videoTitle)
                          .AppendFormat("\"description\":\"{0}\"", videoDesc)
                          .Append("},")
                          .Append("\"msgtype\":\"video\"");
                    break;
            }
            builder.Append("}");
            NetLog.WriteTextLog("ReplayOpenids", builder.ToString(), DateTime.Now);
            var result = client.PostAsync(url, new StringContent(builder.ToString())).Result;
            return JsonHelp.ToDynamic(result.Content.ReadAsStringAsync().Result);
        }

        /// <summary>
        /// 预览接口
        /// 开发者可通过该接口发送消息给指定用户，在手机端查看消息的样式和排版。
        /// </summary>
        /// <param name="access_token"></param>
        /// <param name="openid">接收消息用户对应该公众号的openid</param>
        /// <param name="content">图文消息,语音,图片,视频:media_id(与根据分组群发中的media_id相同); 文本:文本消息</param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static dynamic Preview(string access_token, string openid, string content, WxArtcleType type)
        {
            var url = string.Format("https://api.weixin.qq.com/cgi-bin/message/mass/preview?access_token={0}", access_token);
            var client = new HttpClient();
            var builder = new StringBuilder();
            builder.Append("{")
            .AppendFormat("\"touser\":\"{0}\"",openid)
            .Append(",");
            switch (type)
            {
                case WxArtcleType.News:
                    builder.Append("\"mpnews\":")
                        .Append("{")
                        .AppendFormat("\"media_id\":\"{0}\"", content)
                        .Append("},")
                        .Append("\"msgtype\":\"mpnews\"");
                    break;
                case WxArtcleType.Text:
                    builder.Append("\"text\":")
                       .Append("{")
                       .AppendFormat("\"content\":\"{0}\"", content)
                       .Append("},")
                       .Append("\"msgtype\":\"text\"");
                    break;
                case WxArtcleType.Voice:
                    builder.Append("\"voice\":")
                           .Append("{")
                           .AppendFormat("\"media_id\":\"{0}\"", content)
                           .Append("},")
                           .Append("\"msgtype\":\"voice\"");
                    break;
                case WxArtcleType.Image:
                    builder.Append("\"image\":")
                          .Append("{")
                          .AppendFormat("\"media_id\":\"{0}\"", content)
                          .Append("},")
                          .Append("\"msgtype\":\"image\"");
                    break;
                case WxArtcleType.Video:
                    builder.Append("\"video\":")
                          .Append("{")
                          .AppendFormat("\"media_id\":\"{0}\"", content)
                          .Append("},")
                          .Append("\"msgtype\":\"video\"");
                    break;
            }
            builder.Append("}");
            NetLog.WriteTextLog("Pre", builder.ToString(), DateTime.Now);
            var result = client.PostAsync(url, new StringContent(builder.ToString())).Result;
            return JsonHelp.ToDynamic(result.Content.ReadAsStringAsync().Result);
        }


    }
}
