﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using SeaLee.WeiXin.SDK.Entities;

namespace SeaLee.WeiXin.SDK
{
    public class WxExecutor : IWxExecutor
    {
        public WxExecutor()
        {

        }
        /// <summary>
        /// 返回xml信息
        /// 
        /// </summary>
        /// <param name="message">动态xml类</param>
        /// <returns></returns>
        public string Execute(WxMessage message)
        {
            var result = ""; //返回的xml
            var domain = ConfigurationManager.AppSettings["Domain"];//请更改成你的域名： www.sealee.xin      
            //由 message.Body获取的值都需要用强类型来接受，Body所保存的是接收的xml消息
            //我们发给公众号时    FromUserName:用户    ToUserName：公众号   返回消息时需要互换一下                  
            string fromUserName = message.Body.FromUserName;
            string toUserName = message.Body.ToUserName;
            switch (message.Type) //这里的类型是 用户发过来的
            {
                case WxMessageType.Text: //文字消息
                    #region 文字消息
                    string userMessage = message.Body.Content;
                    result = ReplyMessageAPI.ReplyText(fromUserName, toUserName, "欢迎使用:您输入了：" + userMessage);
                    #endregion
                    break;
                case WxMessageType.Image://图片消息
                    #region 图片消息
                    string imageUrl = message.Body.PicUrl;//图片地址
                    string mediaId = message.Body.MediaId;//mediaId
                    result = ReplyMessageAPI.ReplyImage(fromUserName, toUserName, mediaId);
                    #endregion
                    break;
                case WxMessageType.Voice: //语音消息
                    #region 语音消息
                    {
                        string media_id = message.Body.MediaId;
                        string format = message.Body.Format;
                        string msgId = message.Body.MsgId;
                        result = ReplyMessageAPI.ReplyText(fromUserName, toUserName, string.Format("语音消息:openid:{0},media_id:{1},format:{2},msgId:{3}", fromUserName, media_id, format, msgId));
                    }
                    #endregion 
                    break;
                case WxMessageType.Video: //视频消息
                    #region  视频消息
                    {
                        string media_id = message.Body.MediaId;
                        string thumb_media_id = message.Body.ThumbMediaId;
                        string msgId = message.Body.MsgId;
                        result = ReplyMessageAPI.ReplyText(fromUserName, toUserName, string.Format("视频消息:openid:{0},media_id:{1},thumb_media_id:{2},msgId:{3}", fromUserName, media_id, thumb_media_id, msgId));
                    }
                    #endregion
                    break;
                case WxMessageType.Link: //链接消息
                    #region 链接消息
                    {
                        string title = message.Body.Title;
                        string description = message.Body.Description;
                        string url = message.Body.Url;
                        string msgId = message.Body.MsgId;
                        result = ReplyMessageAPI.ReplyText(fromUserName, toUserName, string.Format("openid:{0},title:{1},description:{2},url:{3},msgId:{4}", fromUserName, title, description, url, msgId));
                    }
                    #endregion
                    break;
                case WxMessageType.Location:  //地理位置消息
                    #region 地理位置消息
                    {
                        string location_X = message.Body.Location_X;
                        string location_Y = message.Body.Location_Y;
                        string scale = message.Body.Scale;
                        string Label = message.Body.Label;
                        //TODO
                        result = ReplyMessageAPI.ReplyText(fromUserName, toUserName, string.Format("地理位置消息: openid:{0},Location_X:{1},Location_Y:{2},Scale:{3},label:{4}", fromUserName, location_X, location_Y, scale, Label));
                    }
                    #endregion
                    break;
                case WxMessageType.Event://事件消息
                    string eventType = message.Body.Event;  //事件类型
                    string eventKey = string.Empty; //自定义事件的钥匙
                    try
                    {
                        eventKey = message.Body.EventKey;
                    }
                    catch { }
                    switch (eventType.ToLower())
                    {
                        case "subscribe"://用户未关注时，进行关注后的事件推送
                            #region 首次关注 
                            if (!string.IsNullOrEmpty(eventKey))   //二维码事件
                            {
                                NetLog.WriteTextLog("EvenKey", eventKey, DateTime.Now);
                                var qrscene = eventKey.Replace("qrscene_", "");//此为场景二维码的场景值
                                result = ReplyMessageAPI.ReplyNews(fromUserName, toUserName,
                                  new WeixinNews
                                  {
                                      title = "欢迎订阅，场景值：" + qrscene,
                                      description = "欢迎订阅，场景值：" + qrscene,
                                      picurl = string.Format("http://{0}/Images/demo.png", domain),
                                      url = domain + "/OAuth/Index"
                                  });
                            }
                            else
                            {
                                result = ReplyMessageAPI.ReplyNews(fromUserName, toUserName,
                                   new WeixinNews
                                   {
                                       title = "欢迎订阅",
                                       description = "欢迎订阅，这是关注事件",
                                       picurl = string.Format("http://{0}/Images/demo.png", domain),
                                       url = domain + "/OAuth/Index"
                                   });
                            }
                            #endregion
                            break;
                        case "unsubscribe"://取消关注
                            #region 取消关注
                            result = ReplyMessageAPI.ReplyText(fromUserName, toUserName, "欢迎再来噢");
                            #endregion
                            break;                    
                        case "location"://上报地理位置事件   
                            #region 上报地理位置事件
                            string lat = message.Body.Latitude;
                            string lng = message.Body.Longitude;
                            string pcn = message.Body.Precision;
                            //TODO:在此处将经纬度记录在数据库,这里用log4net记录日志
                            NetLog.WriteTextLog("上报地理位置：", string.Format("openid:{0} ,location,lat:{1},lng:{2},pcn:{3}", fromUserName, lat, lng, pcn),DateTime.Now);
                            #endregion
                            break;
                        case "click"://自定义点击事件
                            #region 自定义点击事件
                            switch (eventKey)
                            {
                                case "test01":
                                    result = ReplyMessageAPI.ReplyText(fromUserName, toUserName, "跟你说哦,你不要点我呀!");
                                    break;
                                default:
                                    result = ReplyMessageAPI.ReplyText(fromUserName, toUserName, "没有响应菜单事件");
                                    break;
                            }
                            #endregion
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
            return result;
        }

    }
}
