﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

namespace SeaLee.WeiXin.SDK
{
    public class GetLocation
    {
        /// <summary>
        /// 转成百度经纬度
        /// </summary>
        /// <param name="latitude">纬度，浮点数，范围为90 ~ -90</param>
        /// <param name="longitude">经度，浮点数，范围为180 ~ -180</param>
        /// <returns>
        /// 正确：{"status":0,"result":[{"x":114.35447126655663,"y":30.503753989191293}]}
        /// </returns>
        public static dynamic TranCoord(string latitude,string longitude)
        {
            string traURL = string.Format("http://api.map.baidu.com/geoconv/v1/?coords={0},{1}&from=1&to=5&ak=IvX0YcM1IRluCkw2Y0rx6hEYi9Smaw8r",
             longitude, latitude);
            var client = new HttpClient();
            var result = client.GetAsync(traURL).Result;
            return JsonHelp.ToDynamic(result.Content.ReadAsStringAsync().Result);
        }

        /// <summary>
        /// 获取地址
        /// </summary>
        /// <param name="lat">百度地图的纬度</param>
        /// <param name="lon">百度地图的经度</param>
        /// <returns>
        /// 返回的字符串太长了,而且不是一个正确的json格式,直接转是转不了的
        /// 我这里使用一个笨方法就是切割字符串得到json格式。。。。。
        /// </returns>
        public static string Address(string lat,string lon)
        {
            string url = string.Format("http://api.map.baidu.com/geocoder/v2/?callback=renderReverse&location={0},{1}&output=json&pois=1&ak=IvX0YcM1IRluCkw2Y0rx6hEYi9Smaw8r",
            lat, lon);
            var client = new HttpClient();
            var result = client.GetAsync(url).Result;
            string dataJson = result.Content.ReadAsStringAsync().Result;
            dataJson = dataJson.Substring(dataJson.IndexOf('(') + 1);
            dataJson = dataJson.TrimEnd(')');  //得到Json格式
            dynamic newGPS = JsonHelp.ToDynamic(dataJson);
            string address = newGPS.result.formatted_address;
            return address;
        }


    }
}
