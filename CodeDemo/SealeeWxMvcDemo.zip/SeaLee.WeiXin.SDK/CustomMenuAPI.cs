﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;


namespace SeaLee.WeiXin.SDK
{
    /// <summary>
    /// 自定义菜单
    /// 1、click：点击事件，可以根据Key来控制点击后返回的类容（文本，图片，文章等等）  后面做消息返回的时候会仔细介绍
    /// 2、view: url链接
    /// 3、scancode_push：扫码推事件
    /// 4、scancode_waitmsg：扫码推事件且弹出“消息接收中”提示框
    /// 5、pic_sysphoto：弹出系统拍照发图
    /// 6、pic_photo_or_album：弹出拍照或者相册发图
    /// 7、pic_weixin：弹出微信相册发图器
    /// 8、location_select：弹出地理位置选择器
    /// </summary>
    public class CustomMenuAPI
    {

        /// <summary>
        /// 自定义菜单创建接口
        /// http请求方式：POST（请使用https协议） https://api.weixin.qq.com/cgi-bin/menu/create?access_token=ACCESS_TOKEN
        /// </summary>
        /// <param name="token">accessToken 需要获取的</param>
        /// <param name="content">菜单json字符串</param>
        /// <returns>成功返回真,失败返回假</returns>
        public static bool Create(string token,string content)
        {
            var client = new HttpClient();     // System.Net.Http       
            string url = string.Format("https://api.weixin.qq.com/cgi-bin/menu/create?access_token={0}",token);
            var result = client.PostAsync(url, new StringContent(content,Encoding.UTF8, "application/json")).Result;//post传过去的字符串最好编码
            var menu = JsonHelp.ToDynamic(result.Content.ReadAsStringAsync().Result);
            return menu.errcode ==0;
        }



    }
}
