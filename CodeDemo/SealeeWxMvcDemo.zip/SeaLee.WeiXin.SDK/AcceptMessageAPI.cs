﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace SeaLee.WeiXin.SDK
{
    public class AcceptMessageAPI
    {
        /// <summary>
        /// 接收的xml消息
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public static WxMessage Pare(string message) 
        {
            var msg = new WxMessage();
            msg.Body = new DynamicXml(message);
            string msgType = msg.Body.MsgType;
            switch (msgType)
            {
                case "text":
                    msg.Type = WxMessageType.Text;
                    break;
                case "image":
                    msg.Type = WxMessageType.Image;
                    break;
                case "voice":
                    msg.Type = WxMessageType.Voice;
                    break;
                case "video":
                    msg.Type = WxMessageType.Video;
                    break;
                case "location":
                    msg.Type = WxMessageType.Location;
                    break;
                case "link":
                    msg.Type = WxMessageType.Link;
                    break;
                case "event":
                    msg.Type = WxMessageType.Event;
                    break;
                default: throw new Exception("不支持此类型:" + msgType);
            }
            return msg;

        }
     
    }
}
