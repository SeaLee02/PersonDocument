﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeaLee.WeiXin.SDK.Entities
{
    public class WeixinNews
    {
        public string title { set; get; }
        public string description { set; get; }
        public string picurl { set; get; }
        public string url { set; get; }
    }
}
