﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeaLee.WeiXin.SDK
{

    public enum WxMessageType
    {
        Text,//文本
        Location,//地理位置
        Image,//图片
        Voice,//语音
        Video,//视频
        Link,//链接消息
        Event,//事件推送
    }
    public class WxMessage
    {
       public virtual WxMessageType Type { get; set; } //消息类型
        public virtual dynamic Body { get; set; }  //这个需要声明来动态类型来接受xml格式


    }
}
