﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Dynamic;

namespace DynamicDemo
{
  public  class ExpandoDemo
    {

        /// <summary>
        /// Expando测试
        /// </summary>
      public  static void ExpandoTest()
        {
            //这里是把XML和ExpandoObject来做比较
            #region   单个
            XElement contactXML = new XElement("Contact",
                new XElement("Name", "Patrick Hines"),
                new XElement("Phone", "Phone"),
                new XElement("Address",
                    new XElement("Street", "123 Main St"),
                    new XElement("City", "Mercer Island"),
                    new XElement("State", "WA"),
                    new XElement("Postal", "68042")
                    )
            );
            Console.WriteLine("XElement:" + contactXML.Element("Address").Element("City").Value);

            dynamic contact = new ExpandoObject();//声明一个动态类
            contact.Name = "Patrick Hines";  //设置属性和值
            contact.Phone = "Phone";
            contact.Address = new ExpandoObject();
            contact.Address.Street = "123 Main St";
            contact.Address.City = "Mercer Island";
            contact.Address.State = "WA";
            contact.Address.Postal = "68042";
            Console.WriteLine("ExpandoObject:" + contact.Address.City);
            #endregion

            Console.WriteLine("--------------");

            #region  集合
            XElement contactXMLList = new XElement("Contact",
                new XElement("Contact",
                    new XElement("Name", "Jack"),
                    new XElement("Phone", "206-555-0144")
                    ),
               new XElement("Contact",
                    new XElement("Name", "Leo"),
                    new XElement("Phone", "206-555-0155")
                    )
           );
            foreach (var item in contactXMLList.Descendants("Name"))  //找出Name这个节点
                Console.WriteLine("XMLList-->Name:" + item);
            //查询
            var phonesXML = from c in contactXMLList.Descendants("Contact") where c.Element("Name").Value == "Jack" select c.Element("Phone").Value;
            foreach (var item in phonesXML)
                Console.WriteLine("XMLList-->Phone:" + item);
            //删除对象成员
            //contactXMLList.Elements("Contact").Elements("Phone").Remove();
            dynamic contacts = new List<dynamic>();
            contacts.Add(new ExpandoObject());
            contacts[0].Name = "Jack";
            contacts[0].Phone = "206-555-0144";
            contacts.Add(new ExpandoObject());
            contacts[1].Name = "Leo";
            contacts[1].Phone = "206-555-0155";
            foreach (var item in contacts)
            {
                XElement xNode = expandoToXML(item, "Contact"); //把ExpandoObject转化为XML格式
                Console.WriteLine("contacts-->XML:" + xNode);
            }
            foreach (var item in contacts)
                Console.WriteLine("contacts-->Name:" + item.Name);
            //查询 
            var phone = from c in (contacts as List<dynamic>) where c.Name == "Jack" select c.Phone;
            foreach (var item in phone)
                Console.WriteLine("contacts-->phone:" + item);

            //删除  需要转换成字典类型
            //foreach (var item in contacts)
            //{
            //    ((IDictionary<string, object>)item).Remove("Phone");  
            //}


            #endregion
            Console.ReadLine();


            #region 模板
            //dynamic person = new ExpandoObject();
            //// 1。定义属性
            //person.Name = "";
            //person.FirstName = "";
            //// 2。定义实例方法
            //person.ToString = new Func<string>(() => person.Name + "" + person.FirstName);
            //// 3。定义一个事件
            //person.MyEvent = null;
            //person.OnMyEvent = new Action<EventArgs>((e) =>
            //{
            //    if (person.MyEvent != null)
            //        person.MyEvent(person, e);
            //});
            #endregion


        }

        /// <summary>
        /// 把Expando转成XML格式
        /// </summary>
        /// <param name="node">动态类型</param>
        /// <param name="nodeName">Element名称</param>
        /// <returns></returns>
        private static XElement expandoToXML(dynamic node, string nodeName)
        {
            XElement xmlNode = new XElement(nodeName);//创建XElement Contact
            foreach (var property in (IDictionary<string, object>)node)
            {
                if (property.Value.GetType() == typeof(ExpandoObject))  //如果 值 是动态类型
                {
                    xmlNode.Add(expandoToXML(property.Value, property.Key)); //调用本身这个方法 
                }
                else
                {
                    if (property.Value.GetType() == typeof(List<dynamic>))
                    {
                        foreach (var element in (List<dynamic>)property.Value)
                        {
                            xmlNode.Add(expandoToXML(element, property.Key));
                        }
                    }
                    else
                    {
                        xmlNode.Add(new XElement(property.Key, property.Value));
                    }
                }
            }
            return xmlNode;
        }
    }
}
