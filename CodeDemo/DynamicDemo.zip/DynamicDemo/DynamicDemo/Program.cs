﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Dynamic;

namespace DynamicDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Expando类的测试
            //ExpandoDemo.ExpandoTest();

            // DynamicTest();


            string strXML = @"<xml><ToUserName><![CDATA[toUser]]></ToUserName>  
<FromUserName><![CDATA[fromUser]]></FromUserName>
<CreateTime>1348831860</CreateTime> 
<MsgType><![CDATA[text]]></MsgType>  
<Content><![CDATA[this is a test]]></Content>  
<MsgId>1234567890123456</MsgId>  
</xml>";
            //把XML转化为动态类
            XElement xNode = XElement.Parse(strXML);
            dynamic xmlDynamic = new DynamicXml(xNode);
            string content = xmlDynamic.Content;  //接受一下噢
            Console.WriteLine(content);

            //把动态类转化为XML格式
            DynamicXml xmlTest = xmlDynamic;
            string xmlFrom = xmlTest.xNode.ToString();
            Console.WriteLine(xmlFrom);
            Console.ReadLine();




        }


        /// <summary>
        /// 演示DynamicObject
        /// </summary>
        static void DynamicTest()
        {
            XElement contactXML = new XElement("Contact",
               new XElement("Name", "Patrick Hines"),
               new XElement("Phone", "Phone"),
               new XElement("Address",
                   new XElement("Street", "123 Main St"),
                   new XElement("City", "Mercer Island"),
                   new XElement("State", "WA"),
                   new XElement("Postal", "68042")
                   )
           );

            dynamic contact = new DynamicXml("Contacts");
            contact.Name = "Patrick Hines";
            contact.Phone = "206 - 555 - 0144";
            contact.Address = new DynamicXml();
            contact.Address.Street = "123 Main St";
            contact.Address.City = "Mercer Island";
            contact.Address.State = "WA";
            contact.Address.Postal = "68402";

            string aa = contact.Name;  //注:必须接受一个下你的返回值,      如果直接返回 Console.WriteLine(contact.Name);  是得不到你的结果的
            string a = contact.Address.City;
            Console.WriteLine(aa);
            Console.WriteLine(a);
            Console.ReadLine();
        }





    }
}
